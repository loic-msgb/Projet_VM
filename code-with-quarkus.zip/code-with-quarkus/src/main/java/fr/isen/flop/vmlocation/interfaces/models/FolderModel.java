package fr.isen.flop.vmlocation.interfaces.models;


//begin of modifiable zone(Javadoc).......C/dff819c5-3ce9-4bfc-a236-3dbf3c4077e0

//end of modifiable zone(Javadoc).........E/dff819c5-3ce9-4bfc-a236-3dbf3c4077e0
public class FolderModel {
//begin of modifiable zone(Javadoc).......C/7e47c1c0-c0fa-4374-9380-532aefac9c14

//end of modifiable zone(Javadoc).........E/7e47c1c0-c0fa-4374-9380-532aefac9c14
    public int id;

//begin of modifiable zone(Javadoc).......C/8ddb7ba7-de4b-440b-b2f5-983bb6f9b085

//end of modifiable zone(Javadoc).........E/8ddb7ba7-de4b-440b-b2f5-983bb6f9b085
    public String name;

//begin of modifiable zone(Javadoc).......C/f3e35238-2d2c-4a0c-9865-d3112ba41cb6

//end of modifiable zone(Javadoc).........E/f3e35238-2d2c-4a0c-9865-d3112ba41cb6
    public OrganizationModel organization;

}
