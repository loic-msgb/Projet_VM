package fr.isen.flop.vmlocation.interfaces.enums_models;


//begin of modifiable zone(Javadoc).......C/9dbd4fc4-0b63-49c7-8f23-027beb66d118

//end of modifiable zone(Javadoc).........E/9dbd4fc4-0b63-49c7-8f23-027beb66d118
public enum PackType {
//begin of modifiable zone(Javadoc).......C/ed95fa96-c6da-4c2d-99c3-6760540e8608

//end of modifiable zone(Javadoc).........E/ed95fa96-c6da-4c2d-99c3-6760540e8608
    ESSENTIAL,
//begin of modifiable zone(Javadoc).......C/911e9d19-4f65-4f31-9902-fab5ad84e730

//end of modifiable zone(Javadoc).........E/911e9d19-4f65-4f31-9902-fab5ad84e730
    ADVANCED,
//begin of modifiable zone(Javadoc).......C/219068aa-41a5-495c-a8b1-1cd49728a213

//end of modifiable zone(Javadoc).........E/219068aa-41a5-495c-a8b1-1cd49728a213
    PREMIUM;
}
