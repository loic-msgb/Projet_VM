package fr.isen.flop.vmlocation.interfaces.enums_models;


//begin of modifiable zone(Javadoc).......C/f61eeaac-195d-4814-9013-688380061820

//end of modifiable zone(Javadoc).........E/f61eeaac-195d-4814-9013-688380061820
public enum Days {
//begin of modifiable zone(Javadoc).......C/fd2efdad-731c-42a4-b9e3-51145905ba68

//end of modifiable zone(Javadoc).........E/fd2efdad-731c-42a4-b9e3-51145905ba68
    MONDAY,
//begin of modifiable zone(Javadoc).......C/3ba3d28c-0c88-46cf-86f0-f73cb8f843a1

//end of modifiable zone(Javadoc).........E/3ba3d28c-0c88-46cf-86f0-f73cb8f843a1
    TUESDAY,
//begin of modifiable zone(Javadoc).......C/57c81e72-e004-4702-8155-f2d54ec00edf

//end of modifiable zone(Javadoc).........E/57c81e72-e004-4702-8155-f2d54ec00edf
    WEDNESDAY,
//begin of modifiable zone(Javadoc).......C/927a740c-5255-415e-9769-cabec4759092

//end of modifiable zone(Javadoc).........E/927a740c-5255-415e-9769-cabec4759092
    THURSDAY,
//begin of modifiable zone(Javadoc).......C/de46b398-8cca-40b2-ae0c-152ee87ac68f

//end of modifiable zone(Javadoc).........E/de46b398-8cca-40b2-ae0c-152ee87ac68f
    FRIDAY,
//begin of modifiable zone(Javadoc).......C/d57a0341-83fe-4172-a084-c2b820ec68f2

//end of modifiable zone(Javadoc).........E/d57a0341-83fe-4172-a084-c2b820ec68f2
    SATURDAY,
//begin of modifiable zone(Javadoc).......C/abee0873-88c8-4686-beec-9972127828a6

//end of modifiable zone(Javadoc).........E/abee0873-88c8-4686-beec-9972127828a6
    SUNDAY;
}
