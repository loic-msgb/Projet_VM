package fr.isen.flop.vmlocation.interfaces.enums_models;


//begin of modifiable zone(Javadoc).......C/091cfeda-ddb7-49b1-9040-edc16ea9bb3b

//end of modifiable zone(Javadoc).........E/091cfeda-ddb7-49b1-9040-edc16ea9bb3b
public enum Location {
//begin of modifiable zone(Javadoc).......C/31d36ddb-953e-49b6-aae2-f3bf3b3d1c19

//end of modifiable zone(Javadoc).........E/31d36ddb-953e-49b6-aae2-f3bf3b3d1c19
    NA,
//begin of modifiable zone(Javadoc).......C/abfe98c8-6089-450c-8a51-5b5a1d24309b

//end of modifiable zone(Javadoc).........E/abfe98c8-6089-450c-8a51-5b5a1d24309b
    EU,
//begin of modifiable zone(Javadoc).......C/4f0c2667-7ed3-4220-95e8-00c65a081447

//end of modifiable zone(Javadoc).........E/4f0c2667-7ed3-4220-95e8-00c65a081447
    AS;
}
