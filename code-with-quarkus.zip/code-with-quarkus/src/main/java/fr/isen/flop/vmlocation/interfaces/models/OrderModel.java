package fr.isen.flop.vmlocation.interfaces.models;

import fr.isen.flop.vmlocation.interfaces.enums_models.Licence;
import fr.isen.flop.vmlocation.interfaces.enums_models.Location;
import fr.isen.flop.vmlocation.interfaces.enums_models.StatusOrder;

//begin of modifiable zone(Javadoc).......C/dd2d3de1-2d56-47ad-a23a-29cd42129c4f

//end of modifiable zone(Javadoc).........E/dd2d3de1-2d56-47ad-a23a-29cd42129c4f
public class OrderModel {
//begin of modifiable zone(Javadoc).......C/0ef0e7e9-2e64-4db2-acfb-40a1dd114803

//end of modifiable zone(Javadoc).........E/0ef0e7e9-2e64-4db2-acfb-40a1dd114803
    public int id;

//begin of modifiable zone(Javadoc).......C/26a6d6aa-b4c3-4d1e-93e7-2fd540e47eaf

//end of modifiable zone(Javadoc).........E/26a6d6aa-b4c3-4d1e-93e7-2fd540e47eaf
    public Location location;

//begin of modifiable zone(Javadoc).......C/c43c8a4d-5a26-4d73-8771-264c9110423e

//end of modifiable zone(Javadoc).........E/c43c8a4d-5a26-4d73-8771-264c9110423e
    public ServiceLVLModel servicelevel;

//begin of modifiable zone(Javadoc).......C/61a189ff-4ae5-4b32-8f1c-981869289cdd

//end of modifiable zone(Javadoc).........E/61a189ff-4ae5-4b32-8f1c-981869289cdd
    public float monthfee;

//begin of modifiable zone(Javadoc).......C/08fde5e0-b44d-4e51-9891-725ff2132d00

//end of modifiable zone(Javadoc).........E/08fde5e0-b44d-4e51-9891-725ff2132d00
    public float activationfee;

//begin of modifiable zone(Javadoc).......C/9bfd1935-74ff-40d9-a6c7-da231f2e04a7

//end of modifiable zone(Javadoc).........E/9bfd1935-74ff-40d9-a6c7-da231f2e04a7
    public StatusOrder status;

//begin of modifiable zone(Javadoc).......C/98d3dfb7-9364-4dad-a94f-c25892572c9b

//end of modifiable zone(Javadoc).........E/98d3dfb7-9364-4dad-a94f-c25892572c9b
    public Licence licence;

//begin of modifiable zone(Javadoc).......C/230614bb-de8a-4dbb-9649-b82064edf758

//end of modifiable zone(Javadoc).........E/230614bb-de8a-4dbb-9649-b82064edf758
    public int carbonfootprint;

//begin of modifiable zone(Javadoc).......C/3d3b8005-7ac4-4cdd-af83-d34d532d2d01

//end of modifiable zone(Javadoc).........E/3d3b8005-7ac4-4cdd-af83-d34d532d2d01
    public ContactModel contact;

}
