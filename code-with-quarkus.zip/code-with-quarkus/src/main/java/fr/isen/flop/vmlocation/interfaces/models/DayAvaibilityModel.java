package fr.isen.flop.vmlocation.interfaces.models;

import fr.isen.flop.vmlocation.interfaces.enums_models.Days;

//begin of modifiable zone(Javadoc).......C/575268ac-1eea-43fd-9b10-a22942c8469b

//end of modifiable zone(Javadoc).........E/575268ac-1eea-43fd-9b10-a22942c8469b
public class DayAvaibilityModel {
//begin of modifiable zone(Javadoc).......C/ad101754-2f6e-4aeb-a705-8dbfa792164a

//end of modifiable zone(Javadoc).........E/ad101754-2f6e-4aeb-a705-8dbfa792164a
    public String Title;

//begin of modifiable zone(Javadoc).......C/ab055556-7632-4096-9fe1-0197fcd14c50

//end of modifiable zone(Javadoc).........E/ab055556-7632-4096-9fe1-0197fcd14c50
    public boolean Included;

//begin of modifiable zone(Javadoc).......C/c22759b8-c83f-4128-8672-ac82f9a7979b

//end of modifiable zone(Javadoc).........E/c22759b8-c83f-4128-8672-ac82f9a7979b
    public Days day;

//begin of modifiable zone(Javadoc).......C/00e42164-160e-4ec8-bc25-bd1b4fd8888d

//end of modifiable zone(Javadoc).........E/00e42164-160e-4ec8-bc25-bd1b4fd8888d
    public boolean isAM;

//begin of modifiable zone(Javadoc).......C/3e98c234-26e7-4da5-96a4-9b3c6fcbe28f

//end of modifiable zone(Javadoc).........E/3e98c234-26e7-4da5-96a4-9b3c6fcbe28f
    public boolean isPM;

}
