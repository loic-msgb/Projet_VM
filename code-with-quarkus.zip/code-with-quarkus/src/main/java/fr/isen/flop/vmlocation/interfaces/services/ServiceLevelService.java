package fr.isen.flop.vmlocation.interfaces.services;

import fr.isen.flop.vmlocation.interfaces.models.ServiceLVLModel;

//begin of modifiable zone(Javadoc).......C/89a97c7d-93ab-47cb-a6e4-a445c505b89d

//end of modifiable zone(Javadoc).........E/89a97c7d-93ab-47cb-a6e4-a445c505b89d
public interface ServiceLevelService {
//begin of modifiable zone(Javadoc).......C/9421e674-b13d-4ba1-9f2d-1e3cb7fb3b88

//end of modifiable zone(Javadoc).........E/9421e674-b13d-4ba1-9f2d-1e3cb7fb3b88
    ServiceLVLModel GetServiceLevel();

}
