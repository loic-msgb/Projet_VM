package fr.isen.flop.vmlocation.interfaces.services;

import fr.isen.flop.vmlocation.interfaces.models.OrderModel;

//begin of modifiable zone(Javadoc).......C/771fcdbf-d10b-44f8-9caf-64b2c07fae1c

//end of modifiable zone(Javadoc).........E/771fcdbf-d10b-44f8-9caf-64b2c07fae1c
public interface OrderService {
//begin of modifiable zone(Javadoc).......C/84f074ed-59c7-430b-89c9-77bb78108473

//end of modifiable zone(Javadoc).........E/84f074ed-59c7-430b-89c9-77bb78108473
    OrderModel GetOrder();

//begin of modifiable zone(Javadoc).......C/3597a41f-d0ec-49e4-b062-91fc4690a2b9

//end of modifiable zone(Javadoc).........E/3597a41f-d0ec-49e4-b062-91fc4690a2b9
    int CreateOrder(final OrderModel order);

//begin of modifiable zone(Javadoc).......C/94db6bb8-89e2-4029-bc58-2a57a67a0b84

//end of modifiable zone(Javadoc).........E/94db6bb8-89e2-4029-bc58-2a57a67a0b84
    OrderModel UpdateOrder(final OrderModel neworder);

}
