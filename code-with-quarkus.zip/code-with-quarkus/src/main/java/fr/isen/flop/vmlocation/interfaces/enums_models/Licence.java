package fr.isen.flop.vmlocation.interfaces.enums_models;


//begin of modifiable zone(Javadoc).......C/2bb9ddb5-f9bc-4d13-8ec4-727030664d77

//end of modifiable zone(Javadoc).........E/2bb9ddb5-f9bc-4d13-8ec4-727030664d77
public enum Licence {
//begin of modifiable zone(Javadoc).......C/c814ce8d-a2bb-4d84-984d-9329f04e47ed

//end of modifiable zone(Javadoc).........E/c814ce8d-a2bb-4d84-984d-9329f04e47ed
    DEDICATED,
//begin of modifiable zone(Javadoc).......C/f52e07af-74fc-461b-9705-7469b8c1548f

//end of modifiable zone(Javadoc).........E/f52e07af-74fc-461b-9705-7469b8c1548f
    SHARED;
}
