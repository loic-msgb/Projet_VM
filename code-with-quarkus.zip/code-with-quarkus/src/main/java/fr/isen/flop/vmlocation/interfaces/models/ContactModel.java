package fr.isen.flop.vmlocation.interfaces.models;


//begin of modifiable zone(Javadoc).......C/da2b683a-23df-41aa-a77f-e561accaed76

//end of modifiable zone(Javadoc).........E/da2b683a-23df-41aa-a77f-e561accaed76
public class ContactModel {
//begin of modifiable zone(Javadoc).......C/5ea93ff4-5755-49ae-9073-5ea9576998a7

//end of modifiable zone(Javadoc).........E/5ea93ff4-5755-49ae-9073-5ea9576998a7
    public int id;

//begin of modifiable zone(Javadoc).......C/33fbde2e-07bb-49e8-8f3d-fcda26f3ad63

//end of modifiable zone(Javadoc).........E/33fbde2e-07bb-49e8-8f3d-fcda26f3ad63
    public String adress;

//begin of modifiable zone(Javadoc).......C/0e5fd125-244f-42b4-a44f-a226525e806a

//end of modifiable zone(Javadoc).........E/0e5fd125-244f-42b4-a44f-a226525e806a
    public String postalcode;

//begin of modifiable zone(Javadoc).......C/de3da61a-bf66-48e0-913b-8385aeaf85a3

//end of modifiable zone(Javadoc).........E/de3da61a-bf66-48e0-913b-8385aeaf85a3
    public String city;

//begin of modifiable zone(Javadoc).......C/e200b0c3-5423-4d5f-84cd-530c08d8aeb6

//end of modifiable zone(Javadoc).........E/e200b0c3-5423-4d5f-84cd-530c08d8aeb6
    public String country;

//begin of modifiable zone(Javadoc).......C/7b79a400-6cd9-4504-9190-703ce031f0c2

//end of modifiable zone(Javadoc).........E/7b79a400-6cd9-4504-9190-703ce031f0c2
    public String lastname;

//begin of modifiable zone(Javadoc).......C/18596b74-fc03-46a5-820b-b0447f8c4d70

//end of modifiable zone(Javadoc).........E/18596b74-fc03-46a5-820b-b0447f8c4d70
    public String firstname;

//begin of modifiable zone(Javadoc).......C/25e205de-13fd-465a-8be2-583e63526277

//end of modifiable zone(Javadoc).........E/25e205de-13fd-465a-8be2-583e63526277
    public String email;

//begin of modifiable zone(Javadoc).......C/f3094c78-f1ae-427b-ae1d-1558ab2eb0c0

//end of modifiable zone(Javadoc).........E/f3094c78-f1ae-427b-ae1d-1558ab2eb0c0
    public String phonenumber;

//begin of modifiable zone(Javadoc).......C/9ed25cd2-d8a7-4e05-80ca-d2d945f185b4

//end of modifiable zone(Javadoc).........E/9ed25cd2-d8a7-4e05-80ca-d2d945f185b4
    public DayAvaibilityModel[] Avaibility;

}
