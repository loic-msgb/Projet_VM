package fr.isen.flop.vmlocation.interfaces.enums_models;


//begin of modifiable zone(Javadoc).......C/ba0c50ba-8443-4c96-a28b-05e263964a1e

//end of modifiable zone(Javadoc).........E/ba0c50ba-8443-4c96-a28b-05e263964a1e
public enum StatusOrder {
//begin of modifiable zone(Javadoc).......C/a954cbc2-af1a-4d06-8a83-3abf0a18a01b

//end of modifiable zone(Javadoc).........E/a954cbc2-af1a-4d06-8a83-3abf0a18a01b
    IN_PROGRESS,
//begin of modifiable zone(Javadoc).......C/b73bc1a0-77eb-42c4-bea0-542ca63f4ad8

//end of modifiable zone(Javadoc).........E/b73bc1a0-77eb-42c4-bea0-542ca63f4ad8
    PAYMENT_PENDING,
//begin of modifiable zone(Javadoc).......C/65920a7c-539e-40a8-87a1-99c1a04bb536

//end of modifiable zone(Javadoc).........E/65920a7c-539e-40a8-87a1-99c1a04bb536
    OUT_FOR_DELIVERY,
//begin of modifiable zone(Javadoc).......C/8e0a78bd-d1ee-42c8-978a-bc9dc35482c2

//end of modifiable zone(Javadoc).........E/8e0a78bd-d1ee-42c8-978a-bc9dc35482c2
    SAVE_AS_DRAFT,
//begin of modifiable zone(Javadoc).......C/17ce0834-01a3-4973-89c7-9ed791591616

//end of modifiable zone(Javadoc).........E/17ce0834-01a3-4973-89c7-9ed791591616
    DONE;
}
