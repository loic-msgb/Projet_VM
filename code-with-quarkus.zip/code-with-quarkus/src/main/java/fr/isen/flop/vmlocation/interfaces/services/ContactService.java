package fr.isen.flop.vmlocation.interfaces.services;

import fr.isen.flop.vmlocation.interfaces.models.ContactModel;

//begin of modifiable zone(Javadoc).......C/ad4b95ea-c7bf-4818-93aa-183ce850102f

//end of modifiable zone(Javadoc).........E/ad4b95ea-c7bf-4818-93aa-183ce850102f
public interface ContactService {
//begin of modifiable zone(Javadoc).......C/e3bc64f0-82c5-4d78-88f1-d6d71c93bd39

//end of modifiable zone(Javadoc).........E/e3bc64f0-82c5-4d78-88f1-d6d71c93bd39
    ContactModel GetContact();

//begin of modifiable zone(Javadoc).......C/77f7d7db-0f19-4b5b-a9b4-db2f08c88bb2

//end of modifiable zone(Javadoc).........E/77f7d7db-0f19-4b5b-a9b4-db2f08c88bb2
    int CreateContact(final ContactModel contact);

//begin of modifiable zone(Javadoc).......C/4687cd3a-8253-41bf-bf42-21cb5bbecf14

//end of modifiable zone(Javadoc).........E/4687cd3a-8253-41bf-bf42-21cb5bbecf14
    ContactModel UpdateContact(final ContactModel updatedcontact);

}
