package fr.isen.flop.vmlocation.interfaces.services;

import fr.isen.flop.vmlocation.interfaces.models.OrganizationModel;

//begin of modifiable zone(Javadoc).......C/897196a0-5a32-4afa-bfd7-1de6dd3023cf

//end of modifiable zone(Javadoc).........E/897196a0-5a32-4afa-bfd7-1de6dd3023cf
public interface OrganizationService {
//begin of modifiable zone(Javadoc).......C/83f500b9-d82a-41ae-bb75-f23bbf44ec5c

//end of modifiable zone(Javadoc).........E/83f500b9-d82a-41ae-bb75-f23bbf44ec5c
    OrganizationModel GetOrganization();

}
