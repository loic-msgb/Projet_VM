package fr.isen.flop.vmlocation.interfaces.models;


//begin of modifiable zone(Javadoc).......C/e73b97b7-fa4e-45f5-add9-03235ebfdd53

//end of modifiable zone(Javadoc).........E/e73b97b7-fa4e-45f5-add9-03235ebfdd53
public class ProjectModel {
//begin of modifiable zone(Javadoc).......C/257b5dc8-2a13-4789-aaa2-031fdfaa091e

//end of modifiable zone(Javadoc).........E/257b5dc8-2a13-4789-aaa2-031fdfaa091e
    public int id;

//begin of modifiable zone(Javadoc).......C/5e90d428-64e8-4153-b69a-e4d05b50177e

//end of modifiable zone(Javadoc).........E/5e90d428-64e8-4153-b69a-e4d05b50177e
    public String name;

//begin of modifiable zone(Javadoc).......C/222670f7-f294-4f2d-bc65-dad9f86020ff

//end of modifiable zone(Javadoc).........E/222670f7-f294-4f2d-bc65-dad9f86020ff
    public FolderModel folder;

}
