package fr.isen.flop.vmlocation.interfaces.models;

import fr.isen.flop.vmlocation.interfaces.enums_models.PackType;

//begin of modifiable zone(Javadoc).......C/31568f90-f4d9-4b01-9c21-a8ccf84e1f37

//end of modifiable zone(Javadoc).........E/31568f90-f4d9-4b01-9c21-a8ccf84e1f37
public class ServiceLVLModel {
//begin of modifiable zone(Javadoc).......C/d61a6201-e625-4015-9fcc-40271f23c643

//end of modifiable zone(Javadoc).........E/d61a6201-e625-4015-9fcc-40271f23c643
    public PackType packname;

//begin of modifiable zone(Javadoc).......C/488a2ae9-d579-4529-8359-8ed4f9049db2

//end of modifiable zone(Javadoc).........E/488a2ae9-d579-4529-8359-8ed4f9049db2
    public ServicesModel[] services;

//begin of modifiable zone(Javadoc).......C/2fa07d2d-99c6-4c2c-afb7-cccf5f7c60fb

//end of modifiable zone(Javadoc).........E/2fa07d2d-99c6-4c2c-afb7-cccf5f7c60fb
    public int configID ;

}
