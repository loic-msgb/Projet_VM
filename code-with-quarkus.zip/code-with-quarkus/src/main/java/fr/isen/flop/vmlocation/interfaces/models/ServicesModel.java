package fr.isen.flop.vmlocation.interfaces.models;


//begin of modifiable zone(Javadoc).......C/cebd8653-443d-4385-a647-879afbb56b3b

//end of modifiable zone(Javadoc).........E/cebd8653-443d-4385-a647-879afbb56b3b
public class ServicesModel {
//begin of modifiable zone(Javadoc).......C/825adce8-4108-448a-a1d3-28fc6bf75cd0

//end of modifiable zone(Javadoc).........E/825adce8-4108-448a-a1d3-28fc6bf75cd0
    public String Title;

//begin of modifiable zone(Javadoc).......C/dd2b5fe0-26bd-486e-8476-ad7c73ef5bb6

//end of modifiable zone(Javadoc).........E/dd2b5fe0-26bd-486e-8476-ad7c73ef5bb6
    public boolean Included;

}
