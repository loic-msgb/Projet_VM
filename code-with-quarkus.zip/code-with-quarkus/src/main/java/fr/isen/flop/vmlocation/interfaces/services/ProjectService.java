package fr.isen.flop.vmlocation.interfaces.services;

import java.util.List;
import fr.isen.flop.vmlocation.interfaces.models.ProjectModel;

//begin of modifiable zone(Javadoc).......C/603d9a3d-18c1-4d62-8cdf-569bc8c4770e

//end of modifiable zone(Javadoc).........E/603d9a3d-18c1-4d62-8cdf-569bc8c4770e
public interface ProjectService {
//begin of modifiable zone(Javadoc).......C/077b18ec-50a8-427e-b2f5-d1c32a2a22d3

//end of modifiable zone(Javadoc).........E/077b18ec-50a8-427e-b2f5-d1c32a2a22d3
    List<ProjectModel> GetProject();

}
