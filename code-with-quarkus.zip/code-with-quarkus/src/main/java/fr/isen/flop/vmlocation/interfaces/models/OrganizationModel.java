package fr.isen.flop.vmlocation.interfaces.models;


//begin of modifiable zone(Javadoc).......C/ed860f2c-4da4-4619-a0e5-3ed000ba770f

//end of modifiable zone(Javadoc).........E/ed860f2c-4da4-4619-a0e5-3ed000ba770f
public class OrganizationModel {
//begin of modifiable zone(Javadoc).......C/4ac02c08-5d04-4310-adde-4e4da2b1ed8c

//end of modifiable zone(Javadoc).........E/4ac02c08-5d04-4310-adde-4e4da2b1ed8c
    public int id;

//begin of modifiable zone(Javadoc).......C/c9e78310-525d-4c85-b751-7e87c1ed6e99

//end of modifiable zone(Javadoc).........E/c9e78310-525d-4c85-b751-7e87c1ed6e99
    public String name;

//begin of modifiable zone(Javadoc).......C/97edc1da-ec5a-47fe-8e5e-4ecd086b3629

//end of modifiable zone(Javadoc).........E/97edc1da-ec5a-47fe-8e5e-4ecd086b3629
    public String tenant;

}
